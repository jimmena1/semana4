- This is for PERSONAL USE ONLY. NO COMMERCIAL USE ALLOWED!
- NO redistribute ALLOWED!
- For COMMERCIAL USE purchase full version and commercial license,
  please contact us at:
  email: cs.prastart@gmail.com

- go to here for MANUAL USE this font : https://www.youtube.com/channel/UCEG_v_1JducCfCnoi_4hxiA
- Any donation are very appreciated. Paypal account for donation: 
  https://paypal.me/prastart


Best regard,
Prast Art